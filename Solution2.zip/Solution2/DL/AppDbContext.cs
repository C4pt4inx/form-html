﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DL
{
	public class AppDbContext : DbContext
	{
		public AppDbContext()
		{

		}

		public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
		{
		}

		public virtual DbSet<Usuarios> Usuarios { get; set; }
		public virtual DbSet<Pasajeros> Pasajeros { get; set; }
		public virtual DbSet<Vuelos> Vuelos { get; set; }
		public virtual DbSet<VuelosPasajeros> VuelosPasajeros { get; set; }
	}
}
