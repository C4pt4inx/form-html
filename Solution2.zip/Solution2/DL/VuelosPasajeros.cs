﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DL
{
	public class VuelosPasajeros
	{
        public int IdVuelosPasajeros { get; set; }
        public int IdPasajeros { get; set; }
        public int IdVuelos { get; set; }
        public virtual Pasajeros Pasajeros { get; set; }
        public virtual Vuelos Vuelos { get; set; }
    }
}
